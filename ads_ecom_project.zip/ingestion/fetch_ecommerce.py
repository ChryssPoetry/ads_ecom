import pandas as pd
import numpy as np
from datetime import datetime

def fetch_ecommerce():
    np.random.seed(42)

    df = pd.DataFrame({
        "order_id": range(1, 101),
        "customer_id": np.random.randint(1, 50, 100),
        "order_value": np.random.uniform(20, 200, 100).round(2),
        "order_date": pd.date_range("2024-01-01", periods=100)
    })

    df["ingested_at"] = datetime.utcnow()
    df.to_csv("data_raw/ecommerce_raw.csv", index=False)

    print("✅ Ecommerce data fetched")

