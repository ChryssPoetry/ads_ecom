import pandas as pd
import numpy as np
from datetime import datetime

def fetch_web_analytics():
    np.random.seed(42)

    df = pd.DataFrame({
        "session_id": range(1, 201),
        "customer_id": np.random.randint(1, 50, 200),
        "pageviews": np.random.randint(1, 10, 200),
        "session_duration": np.random.uniform(5, 300, 200).round(2),
        "utm_campaign": np.random.choice(
            ["spring_sale", "brand", "retargeting"], 200
        )
    })

    df["ingested_at"] = datetime.utcnow()
    df.to_csv("data_raw/web_analytics_raw.csv", index=False)

    print("✅ Web analytics data fetched")
