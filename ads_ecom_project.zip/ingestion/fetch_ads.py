import pandas as pd
import numpy as np
from datetime import datetime

def fetch_ads():
    np.random.seed(42)

    df = pd.DataFrame({
        "campaign_id": range(1, 201),
        "impressions": np.random.randint(1000, 10000, 200),
        "clicks": np.random.randint(50, 500, 200),
        "cost": np.random.uniform(100, 1000, 200).round(2)
    })

    df["ingested_at"] = datetime.utcnow()

    df.to_csv("data_raw/ads_raw.csv", index=False)
    print("✅ Ads data fetched (synthetic)")
